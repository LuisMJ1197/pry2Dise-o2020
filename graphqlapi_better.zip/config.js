require('dotenv').config()
const mssql = require('mssql');

const pool = new mssql.ConnectionPool({
    server: process.env.DB_SERVER,
    database: process.env.DB_DATABASE,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    "options": {
        "encrypt": true,
        "enableArithAbort": true
    }
});

pool.connect(err => {
    if (err != null) console.log("Error", err);
});

function QueryOne(query) {
    return pool.query(query).then( result => {
        if (result.recordset == []) {
            return null;
        } else {
            return result.recordset[0];
        }
    });
}

function QueryMultiple(query) {
    return pool.query(query).then(result => result.recordset);
}


function QueryMultiples(query) {
    return pool.query(query).then(result => result.recordset[0]);
}

module.exports = {
    QueryOne,
    QueryMultiple,
    QueryMultiples
}