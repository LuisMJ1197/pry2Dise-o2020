const express  = require('express');
const bodyParser = require('body-parser');
const { ApolloServer } = require('apollo-server-express');
const context = require('./model/context');

const app = express();

app.use("/caribejobs", bodyParser.json({limit: '50mb'}));
const server = new ApolloServer({ 
    typeDefs: context.typeDefs,
    resolvers: context.resolverMap,
    formatError: error => {
        console.log(error);
      }
     });
    server.applyMiddleware({ app, path: '/caribejobs'});
// bodyParser is needed just for POST.

app.listen({ port: 4000 }, () =>
    console.log(`Server ready at http://localhost:4000${server.graphqlPath}`)
);

//apollo schema:download --endpoint=http://localhost:4000/caribejobs schema.json