const db  = require("../config");
const { gql } = require("apollo-server-express");
const { merge } = require('lodash');
const users = require('./schema_definitions/users');
const address = require('./schema_definitions/address');
const available_schedule = require('./schema_definitions/available_schedule');
const reference_pictures = require('./schema_definitions/reference_pictures');
const user_professions = require('./schema_definitions/user_professions');
const user_references = require('./schema_definitions/user_references');
const work_zones = require('./schema_definitions/work_zones');
const professions = require('./schema_definitions/professions');
const search = require("./schema_definitions/search");
const db_constants = require("./db_constants");

const schemaInit = gql`
    type Query {
        _empty: String,
        getDirecciones: [Provincia]
    }

    type Mutation {
        _empty: String
    }

    type Result {
        responseMessage: String!,
        resultData: Int,
        errorCode: Int
    }

    type Provincia {
        provinciacod: String,
        provincia: String,
        cantones: [Canton]
    }
    type Canton {
        provinciacod: String,
        cantoncod: String,
        canton: String,
        distritos: [Distrito]
    }
    type Distrito {
        distritocod: String,
        distrito: String
    }
`;

const resolvers = {
    Query: {
        getDirecciones: (parent, args) => {
            const query = `SELECT cod as provinciacod, nombre as provincia FROM provincia ORDER BY provinciacod`;
            return db.QueryMultiple(query);
        }
    },
    Provincia: {
        cantones(parent, args, cts, info) { 
            const query = `SELECT provincia.cod as provinciacod, canton.canton as cantoncod, canton.nombre as canton FROM canton INNER JOIN provincia ON canton.provincia = provincia.cod
                WHERE provincia.cod = '${parent.provinciacod}' ORDER BY provinciacod, cantoncod`;
            return db.QueryMultiple(query);
         }
    },
    Canton: {
        distritos(parent, args, cts, info) { 
            const query = `SELECT distrito.distrito as distritocod, distrito.nombre as distrito 
               FROM distrito INNER JOIN canton ON distrito.canton = canton.canton
                INNER JOIN provincia ON distrito.provincia = provincia.cod AND distrito.canton = canton.canton AND canton.provincia = provincia.cod
                WHERE provincia.cod = '${parent.provinciacod}' AND canton.canton = '${parent.cantoncod}' 
                ORDER BY distritocod`;
            return db.QueryMultiple(query);
         }
    }
}

const typeDefs = [schemaInit, users.schema, address.schema, professions.schema,
    user_professions.schema, available_schedule.schema, work_zones.schema, reference_pictures.schema,
    user_references.schema, search.schema];
const resolverMap = merge(resolvers, users.resolvers, address.resolvers, professions.resolvers,
    user_professions.resolvers, available_schedule.resolvers, work_zones.resolvers, reference_pictures.resolvers,
    user_references.resolvers, search.resolvers);

module.exports = {
    typeDefs, resolverMap
}