const { F_LOGIN, P_SET_PROFILE_PICTURE, 
        F_PROF_BY_USER, F_REFS_PICTURES_BY_USER,
        F_AVAILABLE_SCHE_BY_USER, F_WORK_ZONES_BY_USER,
        F_REFS_BY_USER, F_ADDRESS, P_REGISTER_USER,
        F_USERNAMES_EMAILS } = require("../db_constants");
const db  = require("../../config");
const { gql } = require("apollo-server-express");

const schema = gql`
    extend type Query {
        login(username: String!, password: String!): User,
        getUsernamesEmail: [UE]
    }

    extend type Mutation {
        registerUser(user: UserLoginInput): Result!,
        setProfilePicture(username: String!, imageURL: String!): Result!,
        updateUser(username: String, email: String, phonenumber1: String, phonenumber2: String): Result!
    }
    
    type UE {
        username: String
        email: String
    }
    
    type User {
        username: String,
        firstname: String,
        lastname: String,
        lastname2: String,
        email: String,
        phonenumber1: String,
        phonenumber2: String,
        birthday: String,
        profilePicture: String,
        address: Address
        professions: [UserProfession],
        availableSchedule: [AvailableSchedule],
        workZones: [WorkZone],
        references: [Reference]
    }

    input UserLoginInput {
        username: String,
        password: String,
        firstname: String,
        lastname: String,
        lastname2: String,
        email: String,
        phonenumber1: String,
        phonenumber2: String,
        birthday_day: Int,
        birthday_month: Int,
        birthday_year: Int,
        address: AddressInput
    }
`

const resolvers = {
    Query: {
        login: (parent, args) => {
            const query = F_LOGIN(args);
            return db.QueryOne(query);
        },
        getUsernamesEmail: (parent, args) => {
            const query = F_USERNAMES_EMAILS();
            return db.QueryMultiple(query);
        }
    },
    Mutation: {
        registerUser: (parent, args) => {
            const query = P_REGISTER_USER(args);
            return db.QueryOne(query);
        },
        setProfilePicture: (parent, args) => {
            const query = P_SET_PROFILE_PICTURE(args);
            return db.QueryOne(query);
        },
        updateUser: (parent, args) => {
            const query = `EXEC pUpdateUser 
                @username = '${args.username}',
                @email = '${args.email}',
                @phonenumber1 = '${args.phonenumber1}',
                @phonenumber2 = '${args.phonenumber2}'
            `;
            return db.QueryOne(query);
        }
    },
    User: {
        address(parent) { 
            const query = F_ADDRESS(parent);
            return db.QueryOne(query);
        },
        professions(parent) {
            const query = F_PROF_BY_USER(parent);
            return db.QueryMultiple(query);
        },
        availableSchedule(parent) {
            const query = F_AVAILABLE_SCHE_BY_USER(parent);
            return db.QueryMultiple(query);
        },
        workZones(parent) {
            const query = F_WORK_ZONES_BY_USER(parent);
            return db.QueryMultiple(query);
        },
        references(parent) {
            const query = F_REFS_BY_USER(parent);
            return db.QueryMultiple(query);
        }
    }
}

module.exports = {
    schema,
    resolvers
}