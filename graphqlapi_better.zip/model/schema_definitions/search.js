const db  = require("../../config");
const { gql } = require("apollo-server-express");
const { F_SEARCH_ALL, F_SEARCH_BY_PROFESSION, F_SEARCH_BY_WORKZONE, F_SEARCH_BY_PROFESSION_AND_WORKZONE } = require("../db_constants");

const schema = gql`
    extend type Query {
        searchAll: [User]!,
        searchByProfession(professionid: Int): [User]!,
        searchByWorkZone(provincia: String, canton: String): [User]!,
        searchByProfessionAndWorkZone(professionid: Int, provincia: String, canton: String): [User]!,
    }
`;

const resolvers = {
    Query: {
        searchAll: (parent, args) => {
            const query = F_SEARCH_ALL();
            return db.QueryMultiple(query);
        },
        searchByProfession: (parent, args) => {
            const query = F_SEARCH_BY_PROFESSION(args.professionid);
            return db.QueryMultiple(query);
        },
        searchByWorkZone: (parent, args) => {
            const query = F_SEARCH_BY_WORKZONE(args.provincia, args.canton);
            return db.QueryMultiple(query);
        },
        searchByProfessionAndWorkZone: (parent, args) => {
            const query = F_SEARCH_BY_PROFESSION_AND_WORKZONE(args.professionid, args.provincia, args.canton);
            return db.QueryMultiple(query);
        }
    }
}

module.exports = {
    schema,
    resolvers
}