const db  = require("../../config");
const { gql } = require("apollo-server-express");
const { P_ADD_USER_WORK_ZONE, P_REMOVE_USER_WORK_ZONE } = require("../db_constants");

const schema = gql`
    extend type Mutation {
        addUserWorkZone(workZone: WorkZoneInput): Result!,
        removeUserWorkZone(workZone: WorkZoneInput): Result!
    }

    type WorkZone {
        provincia: String,
        canton: String
    }
    
    input WorkZoneInput {
        username: String,
        provincia: String,
        canton: String
    }
`

const resolvers = {
    Mutation: {
        addUserWorkZone(parent, args) {
            const query = P_ADD_USER_WORK_ZONE(args);
            return db.QueryOne(query);
        },
        removeUserWorkZone(parent, args) {
            const query = P_REMOVE_USER_WORK_ZONE(args);
            return db.QueryOne(query);
        }
    }
}

module.exports = {
    schema,
    resolvers
}