const db  = require("../../config");
const { gql } = require("apollo-server-express");
const { P_ADD_REF_PICTURE, P_REMOVE_REF_PICTURE } = require("../db_constants");

const schema = gql`
    extend type Mutation {
        addReferencePicture(referencePicture: ReferencePictureInput!): Result!,
        removeReferencePictures(username: String!, imageIDs: String!): Result!
    }

    type ReferencePicture {
        imageURL: String,
        imageID: Int
    }
    
    input ReferencePictureInput {
        professionid: Int,
        username: String,
        imageURL: String
    }
`

const resolvers = {
    Mutation: {
        addReferencePicture(parent, args) {
            const query = P_ADD_REF_PICTURE(args);
            return db.QueryOne(query);
        },
        removeReferencePictures(parent, args) {
            const query = P_REMOVE_REF_PICTURE(args);
            return db.QueryOne(query);
        }
    }
}

module.exports = {
    schema,
    resolvers
}