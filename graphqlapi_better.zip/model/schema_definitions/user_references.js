const db  = require("../../config");
const { gql } = require("apollo-server-express");
const { P_ADD_USER_REFERENCE, P_REMOVE_USER_REFERENCES } = require("../db_constants");

const schema = gql`
    extend type Mutation {
        addUserReference(reference: ReferenceInput): Result!,
        removeUserReferences(username: String, referenceids: String): Result!
    }

    input ReferenceInput {
        lastjob: String,
        username: String,
        firstname: String,
        lastname: String,
        lastname2: String,
        phonenumber: String
    }

    type Reference {
        referencenumber: Int,
        lastjob: String,
        firstname: String,
        lastname: String,
        lastname2: String,
        phonenumber: String
    }
`

const resolvers = {
    Mutation: {
        addUserReference(parent, args) {
            const query = P_ADD_USER_REFERENCE(args);
            return db.QueryOne(query);
        },
        removeUserReferences(parent, args) {
            const query = P_REMOVE_USER_REFERENCES(args);
            return db.QueryOne(query);
        }
    }
}

module.exports = {
    schema,
    resolvers
}