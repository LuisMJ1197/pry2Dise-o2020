const db  = require("../../config");
const { gql } = require("apollo-server-express");

const schema = gql`
    extend type Mutation {
        updateAddress(address: AddressInput): Result!
    }

    type Address {
        provincia: String,
        canton: String,
        distrito: String
    }

    input AddressInput {
        username: String,
        provincia: String,
        canton: String,
        distrito: String
    }
`
const resolvers = {
    Mutation: {
        updateAddress (parent, args) {
            const query = `EXEC dbo.pUpdateAddress 
                @username = '${args.address.username}',
                @provincia = '${args.address.provincia}',
                @canton = '${args.address.canton}',
                @distrito = '${args.address.distrito}'
            `;
            return db.QueryOne(query);
        }
    }
}

module.exports = {
    schema,
    resolvers
}