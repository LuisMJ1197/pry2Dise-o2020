const db  = require("../../config");
const { gql } = require("apollo-server-express");
const { F_GET_PROFS } = require("../db_constants");

const schema = gql`
    extend type Query {
        getProfessions: [Profession]
    }

    type Profession {
        professionid: Int,
        professionname: String
    }
`

const resolvers = {
    Query: {
        getProfessions: () => {
            const query = F_GET_PROFS();
            return db.QueryMultiple(query);
        }
    }
}

module.exports = {
    schema,
    resolvers
}