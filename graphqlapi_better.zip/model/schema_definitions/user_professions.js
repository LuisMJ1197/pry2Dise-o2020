const db  = require("../../config");
const { gql } = require("apollo-server-express");
const { F_PROF, P_ADD_USER_PROFESSION,
    P_UPDATE_USER_PROFESSION, P_REMOVE_USER_PROFESSIONS, F_REFS_PICTURES_BY_USER } = require("../db_constants");

const schema = gql`
    extend type Mutation {
        addUserProfession(professionInput: UserProfessionInput!): Result!,
        updateUserProfession(professionInput: UserProfessionInput!): Result!,
        removeUserProfessions(username: String!, professionids: String!): Result!
    }

    type UserProfession {
        professionid: Int,
        profession: Profession,
        experienceyears: Int,
        details: String,
        costperhour: String,
        referencePictures: [ReferencePicture]
    }
    
    input UserProfessionInput {
        username: String,
        professionid: Int,
        experienceyears: Int,
        details: String,
        costperhour: String,
    }
`

const resolvers = {
    Mutation: {
        addUserProfession(parent, args) {
            const query = P_ADD_USER_PROFESSION(args);
            return db.QueryOne(query);
        },
        updateUserProfession(parent, args) {
            const query = P_UPDATE_USER_PROFESSION(args);
            return db.QueryOne(query);
        },
        removeUserProfessions(parent, args) {
            const query = P_REMOVE_USER_PROFESSIONS(args);
            return db.QueryOne(query);
        },
    },
    UserProfession: {
        profession(parent, args) { 
            const query = F_PROF(parent);
            return db.QueryOne(query);
        },
        referencePictures: (parent, args) => {
            const query = F_REFS_PICTURES_BY_USER(parent);
            return db.QueryMultiple(query);
        }
    }
}

module.exports = {
    schema,
    resolvers
}