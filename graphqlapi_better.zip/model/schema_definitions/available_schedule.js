const db  = require("../../config");
const { gql } = require("apollo-server-express");
const { P_UPDATE_AVAILABLE_SCHEDULE, P_CLEAR_AVAILABLE_SCHEDULE } = require("../db_constants");

const schema = gql`
    extend type Mutation {
        updateUserAvailableSchedule(username: String, schedule: [AvailableScheduleInput]): Result!,
        clearUserAvailableScheudle(username: String): Result!
    }

    type AvailableSchedule {
        day: Int,
        startTime: String,
        endTime: String
    }

    input AvailableScheduleInput {
        username: String,
        day: Int,
        startTime: String,
        endTime: String
    }
`

const resolvers = {
    Mutation: {
        updateUserAvailableSchedule(parent, args) {
            var query = "";
            args.schedule.forEach(element => {
                query += query.concat(P_UPDATE_AVAILABLE_SCHEDULE(args.username, element));
            });
            return db.QueryMultiples(query);
        },
        clearUserAvailableScheudle(parent, args) {
            const query = P_CLEAR_AVAILABLE_SCHEDULE(args);
            return db.QueryOne(query);
        }
    }
}

module.exports = {
    schema,
    resolvers
}