const F_USERNAMES_EMAILS = () => {
    const query = `SELECT username, email FROM Users`;
    return query;
}

const F_LOGIN = (args) => {
    const query = `SELECT * FROM fLogin('${args.username}', '${args.password}')`;
    return query;
}

const F_ADDRESS = (args) => {
    const query = `SELECT * FROM fUserAddress('${args.username}')`;
    return query;
}

const F_PROF_BY_USER = (args) => {
    const query = `SELECT * FROM fProfessionsByUser('${args.username}')`;
    return query;
}

const F_PROF = (args) => {
    const query = `SELECT * FROM Professions WHERE professionid = '${args.professionid}'`;
    return query;
}

const F_GET_PROFS = () => {
    const query = `SELECT * FROM dbo.Professions ORDER BY professionname;`;
    return query;
}

const F_AVAILABLE_SCHE_BY_USER = (args) => {
    const query = `SELECT * FROM fAvailableScheduleByUser('${args.username}')`;
    return query;
}

const F_WORK_ZONES_BY_USER = (args) => {
    const query = `SELECT * FROM fWorkZonesByUser('${args.username}')`;
    return query;
}

const F_REFS_BY_USER = (args) => {
    const query = `SELECT * FROM fReferencesByUser('${args.username}')`; 
    return query;
}

const F_REFS_PICTURES_BY_USER = (args) => {
    console.log(args);
    const query = `SELECT * FROM fUserProfessionReferencePictures('${args.username}', '${args.professionid}')`;
    return query;
}


const P_SET_PROFILE_PICTURE = (args) => {
    const query = `EXEC pSetProfilePicture
        @username = '${args.username}',
        @imageURL = '${args.imageURL}'        
    `; 
    return query;
}

P_REGISTER_USER = (args) => {
    const query = `EXEC pRegisterUser
        @username = '${args.user.username}',
        @password = '${args.user.password}',
        @firstname = '${args.user.firstname}',
        @lastname = '${args.user.lastname}',
        @lastname2 = '${args.user.lastname2}',
        @email = '${args.user.email}',
        @phonenumber1 = '${args.user.phonenumber1}',
        @phonenumber2 = '${args.user.phonenumber2}',
        @birthday_day = ${args.user.birthday_day},
        @birthday_month = ${args.user.birthday_month},
        @birthday_year = ${args.user.birthday_year},
        @provincia = '${args.user.address.provincia}',
        @canton = '${args.user.address.canton}',
        @distrito = '${args.user.address.distrito}'
    `;
    return query;
}

const P_ADD_REF_PICTURE = (args) => {
    const query = `EXEC pAddReferencePicture
        @username = '${args.referencePicture.username}',
        @professionid = '${args.referencePicture.professionid}',
        @imageURL = '${args.referencePicture.imageURL}';
    `;
    return query;
}

const P_REMOVE_REF_PICTURE = (args) => {
    const query = `EXEC pRemoveReferencePictureByUsernameAndIDs
        @username = '${args.username}',
        @professionid = '${args.professionid}',
        @imageIDs = '${args.imageIDs}';
    `;
    return query;
}

const P_ADD_USER_PROFESSION = (args) => {
    const query = `EXEC dbo.pAddUserProfession
        @username = '${args.professionInput.username}',
        @professionid = ${args.professionInput.professionid},
        @experienceyears = ${args.professionInput.experienceyears},
        @details = '${args.professionInput.details}',
        @costperhour = '${args.professionInput.costperhour}';
    `;
    return query;
}

const P_UPDATE_USER_PROFESSION = (args) => {
    const query = `EXEC dbo.pUpdateUserProfession
        @username = '${args.professionInput.username}',
        @professionid = ${args.professionInput.professionid},
        @experienceyears = ${args.professionInput.experienceyears},
        @details = '${args.professionInput.details}',
        @costperhour = '${args.professionInput.costperhour}';
    `;
    return query;
}

const P_REMOVE_USER_PROFESSIONS = (args) => {
    const query = `EXEC dbo.pRemoveUserProfessions
        @username = '${args.username}',
        @professionids = ${args.professionids}
    `;
    return query;
}

const P_UPDATE_AVAILABLE_SCHEDULE = (args1, args2) => {
    const query = `EXEC dbo.pUpdateUserAvailableSchedule
        @username = '${args1}',
        @day = ${args2.day},
        @startTime = '${args2.startTime}',
        @endTime = '${args2.endTime}';
    `;
    return query;
}

const P_CLEAR_AVAILABLE_SCHEDULE = (args) => {
    const query = `EXEC dbo.pClearAvailableScheduleByUser
        @username = '${args.username}';
    `;
    return query;
}

const P_ADD_USER_REFERENCE = (args) => {
    const query = `EXEC dbo.pAddUserReference
        @username = '${args.reference.username}',
        @lastjob = '${args.reference.lastjob}',
        @firstname = '${args.reference.firstname}',
        @lastname = '${args.reference.lastname}',
        @lastname2 = '${args.reference.lastname2}',
        @phonenumber = '${args.reference.phonenumber}';
    `;
    return query;
}

const P_REMOVE_USER_REFERENCES = (args) => {
    const query = `EXEC dbo.pRemoveUserReferenceByIds
        @username = '${args.username}',
        @referenceids = '${args.referenceids}';
    `;
    return query;
}

const P_ADD_USER_WORK_ZONE = (args) => {
    const query = `EXEC dbo.pAddUserWorkZone
        @username = '${args.workZone.username}',
        @provincia = '${args.workZone.provincia}',
        @canton = '${args.workZone.canton}';
    `;
    return query;
}

const P_REMOVE_USER_WORK_ZONE = (args) => {
    const query = `EXEC dbo.pRemoveUserWorkZone
        @username = '${args.workZone.username}',
        @provincia = '${args.workZone.provincia}',
        @canton = '${args.workZone.canton}';
    `;
    return query;
}

const F_SEARCH_ALL = () => {
    const query = `
        SELECT * FROM dbo.fSearchAllPeople();
    `;
    return query;
}

const F_SEARCH_BY_PROFESSION = (professionid) => {
    const query = `
        SELECT * FROM dbo.fSearchByProfession(${professionid});
    `;
    return query;
}

const F_SEARCH_BY_PROFESSION_AND_WORKZONE = (professionid, provincia, canton) => {
    const query = `
        SELECT * FROM dbo.fSearchByProfessionAndWorkZone(${professionid}, '${provincia}', '${canton}');
    `;
    return query;
}

const F_SEARCH_BY_WORKZONE = (provincia, canton) => {
    const query = `
        SELECT * FROM dbo.fSearchByWorkZone('${provincia}', '${canton}');
    `;
    return query;
}

module.exports = {
    F_LOGIN,
    F_ADDRESS,
    F_PROF_BY_USER,
    F_PROF,
    F_AVAILABLE_SCHE_BY_USER,
    F_WORK_ZONES_BY_USER,
    F_REFS_BY_USER,
    P_SET_PROFILE_PICTURE,
    F_REFS_PICTURES_BY_USER,
    F_GET_PROFS,
    P_REGISTER_USER,
    F_USERNAMES_EMAILS,
    P_ADD_REF_PICTURE,
    P_REMOVE_REF_PICTURE,
    P_ADD_USER_PROFESSION,
    P_UPDATE_USER_PROFESSION,
    P_REMOVE_USER_PROFESSIONS,
    P_UPDATE_AVAILABLE_SCHEDULE,
    P_CLEAR_AVAILABLE_SCHEDULE,
    P_ADD_USER_REFERENCE,
    P_REMOVE_USER_REFERENCES,
    P_ADD_USER_WORK_ZONE,
    P_REMOVE_USER_WORK_ZONE,
    F_SEARCH_ALL,
    F_SEARCH_BY_PROFESSION,
    F_SEARCH_BY_WORKZONE,
    F_SEARCH_BY_PROFESSION_AND_WORKZONE
}